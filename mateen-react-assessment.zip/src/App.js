import 'animate.css';

//react routing 
import { 
  BrowserRouter as Router, 
  Routes,
  Route 
} from "react-router-dom";


//Import the component
import Home from "./component/Home";
import TaskManagement from "./component/TaskManagement";
import TaskApi from "./component/TaskApi";


const App = ()=>{
  return(
    <>
       <Router>
          <Routes>
              <Route path="/" element={<Home />} />
              <Route path="task-management-system" element={<TaskManagement />} />
              <Route path="get-data-from-fake-api" element={<TaskApi />} />
          </Routes>
       </Router>
    </>
  );
}
export default App;