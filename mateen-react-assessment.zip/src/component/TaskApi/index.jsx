import { useEffect } from 'react';
import { useDispatch,useSelector } from 'react-redux';
import { GetPost } from '../../slices/postSlice'; // import async function from slice



const TaskApi = ()=>{

    const dispatch = useDispatch();
    const {post} = useSelector(response=>response);

    useEffect(()=>{
        dispatch(GetPost())
    },[]);


    return (
        <>
         {/* Loading */}
            {
                post.loading &&  <div className="flex items-center justify-center bg-yellow-50 min-h-screen">
                    <h1 className="text-lg font-semibold">Loading....</h1>
                </div>
            }

{/* When data is avail */}
            {
                (post.loading === false && post.data) && 
                <div className="flex items-center bg-yellow-50 min-h-screen flex-col gap-y-8 p-8 md:px-0 md:py-16">
                    {
                        post.data.map((item,index)=>(
                            <div key={index} className="animate__animated animate__fadeIn p-5 bg-white rounded-lg shadow-lg md:w-3/4">
                                <h1 className="text-2xl font-semibold capitalize">{item.title}</h1>
                                <p className="text-slate-500">{item.body}</p>
                            </div>
                        ))
                    }
                </div>
            }
            {/* Error */}
            {
                (post.loading === false && post.error) && 
                <div className="flex items-center justify-center bg-yellow-50 min-h-screen">
                    <h1 className="text-lg font-semibold">Something is not right</h1>
                </div>
            }
        </>
    )
}

export default TaskApi;
