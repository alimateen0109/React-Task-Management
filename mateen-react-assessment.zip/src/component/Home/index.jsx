// Import Link component to react router dom

//react router dom Link component
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <>
      <div className="h-screen w-screen bg-yellow-100 from-gray-300 to-gray-500 flex flex-col justify-center items-center space-y-4">
        <h1 className="text-4xl text-black">Task Management</h1>

        {/* This is the container of two links button */}
        <div className="flex flex-col items-center">
          <Link
            to="task-management-system"
            className="px-8 py-3 mb-4 bg-blue-500 hover:bg-blue-700 text-white hover:text-gray-200 font-bold rounded-full text-2xl"
          >
            Start Managing Task
          </Link>
          <Link
            to="get-data-from-fake-api"
            className="px-8 py-3 mb-4 bg-green-500 hover:bg-green-700 text-white hover:text-gray-200 font-bold rounded-full text-2xl"
          >
            Api Calling
          </Link>
        </div>
        <h1 className="text-4xl text-black">Mateen Ali</h1>
      </div>
    </>
  );
};
export default Home;
