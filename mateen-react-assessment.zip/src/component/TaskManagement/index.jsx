import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";

//action import from slice
import {
  addNewTask,
  taskDelete,
  toggleComplete,
} from "../../slices/taskManagementSlice";

//headles ui fully assesible user interface  Dialog and transition provided me
import { Dialog, Transition } from "@headlessui/react";
import { Fragment, useRef } from "react";

const TaskManagement = () => {
  // several picies of state to handle task management
  const [isOpen, setIsOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");

  const cancelButtonRef = useRef(null);

  //Global State management
  const dispatch = useDispatch();
  const { tasks } = useSelector((response) => response);

  //event handler function
  const handleaddNewTask = (e) => {
    e.preventDefault();
    if (title && description) {
      dispatch(
        addNewTask({ id: Date.now(), title, description, completed: false })
      );
      setTitle("");
      setDescription("");
      setIsOpen(false);
    } else {
      alert("Required All fields");
    }
  };

  //comp;leted and incompleted seprate fucntions
  const completedTasks = tasks.filter((task) => task.completed);
  const incompletedTasks = tasks.filter((task) => !task.completed);

  return (
    <div className="App  mt-8 px-4 sm:px-6 md:px-8">
      <h1 className="text-3xl font-semibold  text-indigo-600 mb-6">
        Task Management
      </h1>

      <button
        onClick={() => setIsOpen(true)}
        className="animate__animated animate__bounce py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg shadow-md mb-8"
      >
        Add Task
      </button>

      {/* Transition.Root is a wrapper component from @headlessui/react which allows for the handling of complex animations. */}
      <Transition.Root show={isOpen} as={Fragment}>
        <Dialog
          as="div"
          static
          className="fixed z-10 inset-0 overflow-y-auto"
          initialFocus={cancelButtonRef}
          open={isOpen}
          onClose={setIsOpen}
        >
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0"
              enterTo="opacity-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100"
              leaveTo="opacity-0"
            >
              <Dialog.Overlay className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
            </Transition.Child>
            <span
              className="hidden sm:inline-block sm:align-middle sm:h-screen"
              aria-hidden="true"
            >
              &#8203;
            </span>
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
              enterTo="opacity-100 translate-y-0 sm:scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 translate-y-0 sm:scale-100"
              leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            >
              <div className="inline-block align-bottom bg-white rounded-lg px-4 pt-5 pb-4 text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full sm:p-6">
                <div>
                  <h3
                    className="text-lg leading-6 font-medium text-gray-900"
                    id="modal-title"
                  >
                    New Task
                  </h3>
                  <div className="mt-2">
                    <input
                      type="text"
                      placeholder="Title"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="block w-full p-3 rounded-md placeholder-gray-500"
                    />
                    <textarea
                      placeholder="Description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="block w-full p-3 rounded-md placeholder-gray-500 mt-4"
                    />
                  </div>
                </div>
                <div className="mt-5 sm:mt-6">
                  <button
                    type="button"
                    className="animate__animated animate__bounceIn inline-flex justify-center w-full rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:text-sm"
                    onClick={handleaddNewTask}
                  >
                    Add
                  </button>
                </div>
              </div>
            </Transition.Child>
          </div>
        </Dialog>
      </Transition.Root>

      <div className="grid gap-4 grid-cols-1 md:grid-cols-1 mb-8">
        <div>
          <h2 className="text-2xl font-semibold text-indigo-600 mb-4">
            All Tasks
          </h2>
          {renderTaskList(tasks, dispatch)}
        </div>
      </div>

      <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
        <div>
          <h2 className="text-2xl font-semibold text-indigo-600 mb-4">
            Incompleted Tasks
          </h2>
          {renderTaskList(incompletedTasks, dispatch)}
        </div>

        <div>
          <h2 className="text-2xl font-semibold text-indigo-600 mb-4">
            Completed Tasks
          </h2>
          {renderTaskList(completedTasks, dispatch)}
        </div>
      </div>
    </div>
  );
};

const renderTaskList = (taskList, dispatch) => {
  if (taskList.length === 0) {
    return (
      <>
        <div className="text-center py-4 bg-gray-200 text-gray-700">
          No tasks found
        </div>
      </>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full whitespace-nowrap">
        <thead>
          <tr className="text-xs font-semibold tracking-wide text-left text-gray-500 uppercase border-b bg-gray-50">
            <th className="px-4 py-3">Title</th>
            <th className="px-4 py-3">Description</th>
            <th className="px-4 py-3">Actions</th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y">
          {taskList.map((task) => (
            <tr key={task.id} className="text-gray-700">
              <td className="px-4 py-3">{task.title}</td>
              <td className="px-4 py-3 text-sm">{task.description}</td>
              <td className="px-4 py-3 text-sm">
                <button
                  onClick={() => dispatch(toggleComplete(task.id))}
                  className="animate__animated animate__flipInX px-2 py-1 bg-green-500 hover:bg-green-600 text-white rounded-md"
                >
                  {task.completed ? "Mark as Incomplete" : "Mark as Completed"}
                </button>
                <button
                  onClick={() => dispatch(taskDelete(task.id))}
                  className="animate__animated animate__bounceIn px-2 py-1 bg-red-500 hover:bg-red-600 text-white rounded-md ml-2"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TaskManagement;
