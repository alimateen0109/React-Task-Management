import { configureStore,combineReducers } from "@reduxjs/toolkit";

import { persistStore, persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage';


import postSlice from "./slices/postSlice";
import taskManagementSlice from "./slices/taskManagementSlice";



const persistConfig = {
    key: 'root',
    storage,
  };

  const rootReducer = combineReducers({
    post : postSlice,
    tasks : taskManagementSlice
  });

  const persistedReducer = persistReducer(persistConfig, rootReducer);


  const store = configureStore({
    reducer: persistedReducer,
  });
  

  export const persistor = persistStore(store);
  export default store;