import { createSlice } from '@reduxjs/toolkit';

//initial State
const initialState = [];


//redux slice using redux toolkit
const tasksManagementSlice = createSlice({
  name: 'tasks',
  initialState,
  reducers: {
    //adding a new task
     addNewTask : (state,action)=>{
        const {id , title , description } = action.payload;
        state.push({ id, title, description, completed: false });
     },
     //delete task
      taskDelete : (state,action)=>{
        const id = action.payload;
        return state.filter(task => task.id !== id);
      },
      //toggle task complete task
      toggleComplete : (state,action)=>{
        const id = action.payload;
        const task = state.find(task => task.id === id);
        if (task) {
          task.completed = !task.completed;
        }
      }
  },
});

export const { addNewTask, taskDelete, toggleComplete } = tasksManagementSlice.actions;

export default tasksManagementSlice.reducer;
